﻿namespace StudentLibrarySystem.Models
{
    public class Students
    {
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public int PhoneNumber { get; set; }
        public int GradeLevel { get; set; }
    }
}
