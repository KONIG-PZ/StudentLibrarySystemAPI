import ListGroup from "./components/ListGroup";


function App(){
    let items = ["Add Student", "Edit Student", "Delete Student","All Students"];

    const handleSelectItem = (item: string) => {
        console.log(item);
    }

    return (
        <div className="d-flex">
          {/* Sidebar */}
          <div
            className="bg-light p-3"
            style={{ width: "250px", minHeight: "100vh" }}
          >
            <ListGroup
              items={items}
              heading="Student Info"
              onSelectItem={handleSelectItem}
            />
          </div>

          {/* Main content */}
          <div className="flex-grow-1 p-4">
            {/* Your page content here */}
          </div>
        </div>
    );
    }

export default App;