import { useState } from 'react';

interface Student {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber?: string;
  gradeLevel: number;
}

function SelectStudent() {
  const [searchId, setSearchId] = useState('');
  const [searchFirstName, setSearchFirstName] = useState('');
  const [searchLastName, setSearchLastName] = useState('');
  const [searchGradeLevel, setSearchGradeLevel] = useState('');
  
  const [student, setStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function fetchStudent() {
    try {
      setLoading(true);
      setError('');
      setStudent(null);


      const BACKEND_URL = 'https://localhost:7231';
      // If searching by ID, use the specific endpoint
      if (searchId.trim()) {
        const response = await fetch(`${BACKEND_URL}/api/Student/${searchId}`);
        
        if (!response.ok) {
          throw new Error('Student not found');
        }
        
        const data: Student = await response.json();
        setStudent(data);
        setLoading(false);
        return;
      }
      
      // Otherwise, fetch all students and filter
      const response = await fetch(`${BACKEND_URL}/api/Student`);

      if (!response.ok) {
        throw new Error('Failed to fetch students');
      }

      const students: Student[] = await response.json();
      
      // Filter students based on search criteria
      let filteredStudents = students;

      if (searchFirstName.trim()) {
        filteredStudents = filteredStudents.filter(s => 
          s.firstName.toLowerCase().includes(searchFirstName.toLowerCase())
        );
      }

      if (searchLastName.trim()) {
        filteredStudents = filteredStudents.filter(s => 
          s.lastName.toLowerCase().includes(searchLastName.toLowerCase())
        );
      }

      if (searchGradeLevel.trim()) {
        const grade = parseInt(searchGradeLevel);
        if (!isNaN(grade)) {
          filteredStudents = filteredStudents.filter(s => s.gradeLevel === grade);
        }
      }

      if (filteredStudents.length > 0) {
        setStudent(filteredStudents[0]); // Show first match
        setError(filteredStudents.length > 1 ? `Found ${filteredStudents.length} students. Showing first match.` : '');
      } else {
        setStudent(null);
        setError('No student found matching the criteria');
      }
      
      setLoading(false);
    } catch (err) {
      console.error('Error fetching student:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch student data');
      setStudent(null);
      setLoading(false);
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if at least one field is filled
    if (!searchId.trim() && !searchFirstName.trim() && !searchLastName.trim() && !searchGradeLevel.trim()) {
      setError('Please enter at least one search criteria');
      return;
    }
    
    fetchStudent();
  };

  const handleClear = () => {
    setSearchId('');
    setSearchFirstName('');
    setSearchLastName('');
    setSearchGradeLevel('');
    setStudent(null);
    setError('');
  };

  return (
    <div className="container mt-4">
      <h2>Select Student</h2>
      <p className="text-muted">Search by ID or any combination of name/grade level</p>
      
      <form onSubmit={handleSubmit}>
        {/* Search by ID */}
        <div className="mb-3">
          <label htmlFor="searchId" className="form-label">Student ID</label>
          <input 
            type="text" 
            className="form-control"
            id="searchId"
            placeholder="e.g., 123e4567-e89b-12d3-a456-426614174000" 
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
          />
          <small className="text-muted">Search by exact ID (fastest)</small>
        </div>

        <div className="text-center my-3">
          <strong>— OR —</strong>
        </div>

        {/* Search by Name & Grade */}
        <div className="row">
          <div className="col-md-4 mb-3">
            <label htmlFor="searchFirstName" className="form-label">First Name</label>
            <input 
              type="text" 
              className="form-control"
              id="searchFirstName"
              placeholder="John" 
              value={searchFirstName}
              onChange={(e) => setSearchFirstName(e.target.value)}
            />
          </div>

          <div className="col-md-4 mb-3">
            <label htmlFor="searchLastName" className="form-label">Last Name</label>
            <input 
              type="text" 
              className="form-control"
              id="searchLastName"
              placeholder="Doe" 
              value={searchLastName}
              onChange={(e) => setSearchLastName(e.target.value)}
            />
          </div>

          <div className="col-md-4 mb-3">
            <label htmlFor="searchGradeLevel" className="form-label">Grade Level</label>
            <input 
              type="number" 
              className="form-control"
              id="searchGradeLevel"
              placeholder="1-12" 
              min="1"
              max="12"
              value={searchGradeLevel}
              onChange={(e) => setSearchGradeLevel(e.target.value)}
            />
          </div>
        </div>
        
        <div className="d-flex gap-2">
          <button 
            type="submit" 
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? 'Searching...' : 'Search Student'}
          </button>

          <button 
            type="button" 
            className="btn btn-secondary"
            onClick={handleClear}
          >
            Clear
          </button>
        </div>
      </form>

      {/* Error Message */}
      {error && (
        <div className={`alert ${student ? 'alert-info' : 'alert-danger'} mt-3`}>
          {error}
        </div>
      )}

      {/* Student Info Card */}
      {student && (
        <div className="card mt-4">
          <div className="card-header bg-primary text-white">
            <h5 className="mb-0">Student Information</h5>
          </div>
          <div className="card-body">
            <div className="row">
              <div className="col-md-6">
                <p><strong>ID:</strong> {student.id}</p>
                <p><strong>First Name:</strong> {student.firstName}</p>
                <p><strong>Last Name:</strong> {student.lastName}</p>
              </div>
              <div className="col-md-6">
                <p><strong>Email:</strong> {student.email}</p>
                <p><strong>Phone:</strong> {student.phoneNumber || 'N/A'}</p>
                <p><strong>Grade Level:</strong> {student.gradeLevel}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default SelectStudent;