function SelectStudent() {
  return (
    <div>
      <h2>Select Student</h2>
      <form>
        <input type="text" placeholder="Student Name" />
        <button type="submit">Select</button>
      </form>
    </div>
  );
}

export default SelectStudent;