function AddStudent() {
  return (
    <div>
      <h2>Add Student</h2>
      <form>
        <input type="text" placeholder="Student Name" />
        <button type="submit">Add</button>
      </form>
    </div>
  );
}

export default AddStudent;