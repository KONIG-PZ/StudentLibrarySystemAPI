
function AddStudent() {
  return (
    <div>
      <h2>Add Students</h2>
      <form>
        <input type="text" placeholder="Student Name" />
        <button type="submit">Add Students</button>
      </form>
    </div>
  );

}

export default AddStudent;

