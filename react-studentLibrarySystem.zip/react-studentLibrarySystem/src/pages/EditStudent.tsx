function EditStudent() {
  return (
    <div>
      <h2>Edit Student</h2>
      <form>
        <input type="text" placeholder="Student Name" />
        <button type="submit">Edit</button>
      </form>
    </div>
  );
}

export default EditStudent;