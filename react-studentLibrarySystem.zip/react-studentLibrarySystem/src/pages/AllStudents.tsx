function AllStudents() {
  return (
    <div>
      <h2>All Students</h2>
      <form>
        <input type="text" placeholder="Student Name" />
        <button type="submit">All Students</button>
      </form>
    </div>
  );
}

export default AllStudents;