function DeleteStudent() {
  return (
    <div>
      <h2>Delete Student</h2>
      <form>
        <input type="text" placeholder="Student Name" />
        <button type="submit">Delete</button>
      </form>
    </div>
  );
}

export default DeleteStudent;